package snakegame;

public enum TileType {
	
	EMPTY,
	
	FOOD

}
