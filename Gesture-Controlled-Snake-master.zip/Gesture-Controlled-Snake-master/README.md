# Gesture-Controlled-Snake
Snake Game, played via hand gestures
This is a Java based simple game of Snake, which uses Machile learning and neural networks to recognise hand gestures in live video using Keras and Python. And performing the said task after image recognition.
