java -jar simple-snake/dist/simple-snake.jar & python3 train_test.py
